export default eventHandler(() => {
  return { nitro: 'Is Awesome! asda' };
});
