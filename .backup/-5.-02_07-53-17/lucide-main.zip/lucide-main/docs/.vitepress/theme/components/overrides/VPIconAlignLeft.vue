<script setup lang="ts">
import { menu } from '../../../data/iconNodes'
import createLucideIcon from 'lucide-vue-next/src/createLucideIcon'

const Menu = createLucideIcon('menu', menu)
</script>

<template>
  <Menu />
</template>
