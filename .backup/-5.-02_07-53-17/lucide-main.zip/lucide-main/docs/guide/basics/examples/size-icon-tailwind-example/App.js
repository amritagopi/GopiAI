import { PartyPopper } from "lucide-react";

function App() {
  return (
    <div>
      <PartyPopper className="w-24 h-24" />
    </div>
  );
}

export default App;
